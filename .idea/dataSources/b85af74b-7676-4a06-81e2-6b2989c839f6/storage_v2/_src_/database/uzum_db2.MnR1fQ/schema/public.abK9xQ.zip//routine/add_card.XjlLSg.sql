create function add_card(i_serial_number character varying, i_card_type character varying, i_card_date timestamp without time zone, i_password integer, i_balance double precision) returns integer
    language plpgsql
as
$$
declare
    v_serial_number varchar := null;
    v_id int;
begin
    select serial_number into v_serial_number from card where serial_number = i_serial_number;
    if v_serial_number is null then
        insert into card(serial_number, card_type, card_date, password, balance) values
            (i_serial_number, i_card_type, i_card_date, i_password, i_balance) returning id into v_id;
        return v_id;
    end if;
    return -1;
end;
$$;

alter function add_card(varchar, varchar, timestamp, integer, double precision) owner to postgres;

