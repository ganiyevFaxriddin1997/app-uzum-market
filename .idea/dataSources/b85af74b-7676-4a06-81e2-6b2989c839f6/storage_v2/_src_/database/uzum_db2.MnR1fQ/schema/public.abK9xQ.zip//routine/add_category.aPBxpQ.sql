create function add_category(i_name character varying) returns integer
    language plpgsql
as
$$
declare
    v_name varchar := null;
    v_id int;
begin
    select name into v_name from category where name = i_name;
    if v_name is null then
        insert into category(name) values (i_name)returning id into v_id;
        return v_id;
    end if;
    return -1;
end;
$$;

alter function add_category(varchar) owner to postgres;

