create function add_payment(i_card_id integer, i_price double precision) returns integer
    language plpgsql
as
$$
declare
    v_id int;
begin
        insert into payment( card_id, price)
        values (i_card_id,i_price) returning id into v_id;
           return v_id;
end;
$$;

alter function add_payment(integer, double precision) owner to postgres;

