create function add_product(i_name character varying, i_price double precision, i_sub_category_id integer, i_description character varying, i_color character varying, i_size character varying, i_owner_id integer, i_amount integer, i_brand character varying) returns integer
    language plpgsql
as
$$
declare
    v_name varchar := null;
    v_sub_category_id int := null;
    v_id int;
begin
    select name into  v_name from product where name = i_name and price=i_price and color = i_color and
            brand = i_brand and description = i_description and size = i_size and
            sub_category_id = i_sub_category_id;

    select id into v_sub_category_id from sub_category where id = i_sub_category_id;

    if v_name is null and (v_sub_category_id is not null) then
        insert into product(name, price, sub_category_id, description, color, size, owner_id, amount, brand)
        values (i_name, i_price, i_sub_category_id, i_description, i_color, i_size, i_owner_id, i_amount, i_brand) returning id into v_id;
        return v_id;
    end if;
    return -1;
end;
$$;

alter function add_product(varchar, double precision, integer, varchar, varchar, varchar, integer, integer, varchar) owner to postgres;

