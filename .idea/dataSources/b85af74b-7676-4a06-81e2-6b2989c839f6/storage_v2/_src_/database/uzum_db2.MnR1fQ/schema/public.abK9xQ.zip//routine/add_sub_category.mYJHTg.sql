create function add_sub_category(i_name character varying, i_category_id integer) returns integer
    language plpgsql
as
$$
declare
    v_name varchar := null;
    v_id int;
begin
    select name into v_name from sub_category where name = i_name and sub_category.category_id = i_category_id;
    if v_name is null then
        insert into sub_category(name, category_id)
        values (i_name, i_category_id) returning id into v_id;
        return v_id;
    end if;
    return -1;
end;
$$;

alter function add_sub_category(varchar, integer) owner to postgres;

