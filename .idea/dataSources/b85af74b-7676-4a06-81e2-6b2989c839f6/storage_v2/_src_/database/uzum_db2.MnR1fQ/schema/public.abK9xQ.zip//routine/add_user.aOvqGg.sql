create function add_user(i_name character varying, i_phone character varying, i_role character varying, i_gender character varying) returns integer
    language plpgsql
as
$$
declare
    v_name varchar := null;
    v_id integer;
begin
    select name into v_name from users where phone = i_phone;
    if v_name is null then
        insert into users(name, phone, role, gender) values
            (i_name, i_phone, i_role, i_gender) returning id into v_id;
        return v_id;
    end if;
    return -1;
end;
$$;

alter function add_user(varchar, varchar, varchar, varchar) owner to postgres;

