create function check_products_from_basket(i_user_id integer, i_name character varying) returns integer
    language plpgsql
as
$$
declare
    v_name varchar := null;
    v_product_id int:= -1;
begin
    select p.name
    into v_name
    from product p
             join orders o on p.id = o.product_id
             join basket b on o.id = b.order_id
    where b.user_id = i_user_id
      and p.name = i_name;

    if v_name is not null then
        select distinct p2.id into v_product_id
        from orders o
                 join product p2 on o.product_id = p2.id
        where p2.name = i_name;
        return v_product_id;
    end if;
    return v_product_id;
end ;
$$;

alter function check_products_from_basket(integer, varchar) owner to postgres;

