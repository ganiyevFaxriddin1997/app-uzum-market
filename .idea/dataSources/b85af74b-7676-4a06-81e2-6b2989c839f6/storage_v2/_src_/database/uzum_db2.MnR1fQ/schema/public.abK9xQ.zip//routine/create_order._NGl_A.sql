create function create_order(i_user_id integer, i_product_id integer, i_amount integer) returns integer
    language plpgsql
as
$$
declare
    v_id int;
begin
            insert into orders(user_id, product_id, amount)
        values (i_user_id, i_product_id, i_amount) returning id into v_id;
        return v_id;
end;
$$;

alter function create_order(integer, integer, integer) owner to postgres;

