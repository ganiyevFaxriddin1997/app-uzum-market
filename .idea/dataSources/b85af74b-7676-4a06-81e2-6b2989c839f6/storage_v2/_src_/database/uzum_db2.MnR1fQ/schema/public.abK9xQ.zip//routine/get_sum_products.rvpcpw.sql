create function get_sum_products(i_user_id integer) returns numeric
    language plpgsql
as
$$
    declare sum_product numeric := 0;
    begin
        select sum(p.price * o.amount) into sum_product
        from product p
                 join orders o on p.id = o.product_id
                 join basket b on o.id = b.order_id
        where b.user_id = 3;
        return sum_product;
    end;
    $$;

alter function get_sum_products(integer) owner to postgres;

