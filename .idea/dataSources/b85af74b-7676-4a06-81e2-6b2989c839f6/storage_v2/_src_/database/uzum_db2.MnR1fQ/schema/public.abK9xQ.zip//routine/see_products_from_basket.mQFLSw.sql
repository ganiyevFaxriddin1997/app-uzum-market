create function see_products_from_basket(i_user_id integer)
    returns TABLE(u_name character varying, price double precision, description character varying, color character varying, size character varying, brand character varying, amount integer)
    language plpgsql
as
$$
begin
    return query
        select p.name, p.price, p.description, p.color, p.size, p.brand, o.amount
        from product p
                 join orders o on p.id = o.product_id
                 join basket b on o.id = b.order_id
        where b.user_id = i_user_id;
end;
$$;

alter function see_products_from_basket(integer) owner to postgres;

